/*
 * Copyright (c)  2018, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.wso2.extension.siddhi.execution.bny.streamfunction;

import org.wso2.siddhi.annotation.Example;
import org.wso2.siddhi.annotation.Extension;
import org.wso2.siddhi.annotation.Parameter;
import org.wso2.siddhi.annotation.ReturnAttribute;
import org.wso2.siddhi.annotation.util.DataType;
import org.wso2.siddhi.core.config.SiddhiAppContext;
import org.wso2.siddhi.core.executor.ExpressionExecutor;
import org.wso2.siddhi.core.executor.VariableExpressionExecutor;
import org.wso2.siddhi.core.executor.function.FunctionExecutor;
import org.wso2.siddhi.core.util.config.ConfigReader;
import org.wso2.siddhi.query.api.definition.Attribute;
import org.wso2.siddhi.query.api.exception.SiddhiAppValidationException;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * createMap(MQ_Raw_Event, GroupedKeys)
 * Returns a map with extracted keys and values.
 * Accept Type(s): (STRING,STRING)
 * Return Type(s): OBJECT
 */

@Extension(
        name = "createMapFromRef",
        namespace = "bny",
        description = "Returns a map with values extracted from the raw event. ",
        parameters = {
                @Parameter(name = "raw.input.string",
                        description = "The input string to be processed.",
                        type = {DataType.STRING}),
                @Parameter(name = "process.string",
                        description = "Process string",
                        type = {DataType.STRING})
        },
        returnAttributes = @ReturnAttribute(
                description = "This returns a map with values extracted from the raw event.",
                type = {DataType.OBJECT}),
        examples = @Example(description = "This returns a boolean value by evaluation the given expression. " +
                "In this case, it will return true as the output",
                syntax = "bny:eval(\"10 > 5\")")
)
public class CreateMapFromReferenceFunctionExtension extends FunctionExecutor {

    private static final int PARAMETER_MAX_COUNT = 8;
    Attribute.Type returnType = Attribute.Type.OBJECT;
    List<String> attrList = new ArrayList<>();

    @Override
    protected void init(ExpressionExecutor[] attributeExpressionExecutors, ConfigReader configReader,
                        SiddhiAppContext siddhiAppContext) {

        for (int i = 1; i < PARAMETER_MAX_COUNT; i++) {
            if (attributeExpressionExecutors[i] != null) {
                attrList.add(((VariableExpressionExecutor) attributeExpressionExecutors[i]).getAttribute().getName());
            } else {
                throw new SiddhiAppValidationException(String.format("CreateMapFromReferenceFunctionExtension " +
                        "%s parameter needs to be non empty", i));
            }
        }
    }

    @Override
    protected Object execute(Object[] data) {

        Map<String, String> propertiesMap;
        propertiesMap = (LinkedHashMap<String, String>) data[0];
        for (int i = 1; i < PARAMETER_MAX_COUNT; i++) {
            String attribute = attrList.get(i - 1);
            if (propertiesMap.get(data[i]) == null) {
                propertiesMap.put(attribute, (String) data[i]);
            } else {
                propertiesMap.put(attribute, propertiesMap.get(data[i]));
            }
        }
        return propertiesMap;
    }

    @Override
    protected Object execute(Object data) {

        return null;  //Since the CreateMapFromReference function takes in exactly 2 parameters,
        // this method does not get called.
        // Hence, not implemented.
    }

    @Override
    public Attribute.Type getReturnType() {

        return returnType;
    }

    @Override
    public Map<String, Object> currentState() {

        return null;    //No need to maintain a state.
    }

    @Override
    public void restoreState(Map<String, Object> map) {

    }
}
