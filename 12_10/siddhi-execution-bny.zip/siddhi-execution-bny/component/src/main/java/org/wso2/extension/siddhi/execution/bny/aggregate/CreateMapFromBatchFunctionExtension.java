/*
 * Copyright (c) 2018, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.wso2.extension.siddhi.execution.bny.aggregate;

import org.wso2.siddhi.annotation.Example;
import org.wso2.siddhi.annotation.Extension;
import org.wso2.siddhi.annotation.Parameter;
import org.wso2.siddhi.annotation.ReturnAttribute;
import org.wso2.siddhi.annotation.util.DataType;
import org.wso2.siddhi.core.config.SiddhiAppContext;
import org.wso2.siddhi.core.exception.SiddhiAppRuntimeException;
import org.wso2.siddhi.core.executor.ExpressionExecutor;
import org.wso2.siddhi.core.query.selector.attribute.aggregator.AttributeAggregator;
import org.wso2.siddhi.core.util.config.ConfigReader;
import org.wso2.siddhi.query.api.definition.Attribute;
import org.wso2.siddhi.query.api.exception.SiddhiAppValidationException;

import java.util.HashMap;
import java.util.Map;

/**
 * groupConcat(key1, key2, key3...)
 * Returns concatenated string for all the events separated by a comma(,).
 * Accept Type(s): STRING. The strings that need to be aggregated.
 * Return Type(s): STRING
 */
@Extension(
        name = "createMapFromBatch",
        namespace = "bny",
        description = "Aggregates the received events by concatenating the values of those events for the given keys "
                + "using a separator, comma (,) and returns the concatenated string.",
        parameters = {
                @Parameter(name = "key.list",
                        description = "The string that need to be aggregated.",
                        type = {DataType.STRING})
        },
        returnAttributes = @ReturnAttribute(
                description = "Returns a string that is the result of the concatenated values of the provided keys "
                        + "separated by a comma (,)",
                type = {DataType.STRING}),
        examples = @Example(description = "This returns a concatenated string for the event chunk with values "
                + "for the given keys. In this scenario, the output is "
                + "AppCode#Data#3#NOEXPAND#NOCOPY, TransType#Data#3#NOEXPAND#NOCOPY...",
                syntax = "groupConcat(FLD_NM, FLD_DATA_TYPE, FLD_DATA_SIZE, FLD_EXPA, FLD_COPY) ")
)
public class CreateMapFromBatchFunctionExtension extends AttributeAggregator {

    private Attribute.Type returnType = Attribute.Type.OBJECT;
    private Map<String, String> dataSet;
    private boolean canDistroy = true;

    @Override
    protected void init(ExpressionExecutor[] attributeExpressionExecutors, ConfigReader configReader,
                        SiddhiAppContext siddhiAppContext) {

        if (attributeExpressionExecutors.length != 2) {
            throw new SiddhiAppValidationException("bny:createMapFromBatch() function requires exactly " +
                    "two attributes.");
        }
        dataSet = new HashMap<>();
    }

    @Override
    public Attribute.Type getReturnType() {

        return returnType;
    }

    @Override
    public Object processAdd(Object o) {

        return null;  //Since the groupConcat function requires two or more keys, this method does not get called.
        // Hence, not implemented.
    }

    @Override
    public synchronized Object processAdd(Object[] objects) {

        for (int i = 0; i < objects.length; i++) {
            if (objects[i] == null) {
                throw new SiddhiAppRuntimeException(String.format("bny:groupConcat() function requires " +
                        "not null attribute for index: %s", i + 1));
            }
        }
        String key = (String) objects[0];
        String value = (String) objects[1];
        dataSet.put(key, value);
        return dataSet;
    }

    @Override
    public Object processRemove(Object o) {
        return null;
    }

    @Override
    public Object processRemove(Object[] objects) {
        dataSet.remove(objects[1]);
        return dataSet;
    }

    @Override
    public boolean canDestroy() {
        return canDistroy;
    }

    @Override
    public Object reset() {
        dataSet.clear();
        canDistroy = true;
        return "";
    }

    @Override
    public Map<String, Object> currentState() {
        HashMap<String, Object> state = new HashMap<>();
        state.put("dataSet", dataSet);
        return state;
    }

    @Override
    public void restoreState(Map<String, Object> state) {
        dataSet = (Map<String, String>) state.get("dataSet");
    }
}
