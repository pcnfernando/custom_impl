package org.wso2.extension.siddhi.execution.bny.streamfunction;

public class TestCaseOfBNYStreamFunction {

}
