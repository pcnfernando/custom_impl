package org.wso2.extension.siddhi.execution.bny.aggregate;

public class TestCaseOfBNYAggregateFunction {

}

