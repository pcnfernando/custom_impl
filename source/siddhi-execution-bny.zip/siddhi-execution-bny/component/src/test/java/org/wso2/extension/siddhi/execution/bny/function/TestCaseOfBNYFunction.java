package org.wso2.extension.siddhi.execution.bny.function;

public class TestCaseOfBNYFunction {

}
