package org.wso2.extension.siddhi.execution.bny.streamprocessor;

import org.apache.log4j.Logger;
import org.wso2.siddhi.annotation.Example;
import org.wso2.siddhi.annotation.Extension;
import org.wso2.siddhi.annotation.Parameter;
import org.wso2.siddhi.annotation.ReturnAttribute;
import org.wso2.siddhi.annotation.util.DataType;
import org.wso2.siddhi.core.config.SiddhiAppContext;
import org.wso2.siddhi.core.event.ComplexEventChunk;
import org.wso2.siddhi.core.event.stream.StreamEvent;
import org.wso2.siddhi.core.event.stream.StreamEventCloner;
import org.wso2.siddhi.core.event.stream.populater.ComplexEventPopulater;
import org.wso2.siddhi.core.executor.ExpressionExecutor;
import org.wso2.siddhi.core.query.processor.Processor;
import org.wso2.siddhi.core.query.processor.stream.StreamProcessor;
import org.wso2.siddhi.core.util.config.ConfigReader;
import org.wso2.siddhi.query.api.definition.AbstractDefinition;
import org.wso2.siddhi.query.api.definition.Attribute;
import org.wso2.siddhi.query.api.exception.SiddhiAppValidationException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/**
 * This is a sample class-level comment, explaining what the extension class does.
 */

@Extension(
        name = "eval",
        namespace = "bny",
        description = "Returns a string that is the result of concatenating two or more input string values.",
        parameters = {
                @Parameter(name = "exp",
                        description = "It can have two or more `string` type input parameters.",
                        type = {DataType.STRING})
        },
        returnAttributes = {
                @ReturnAttribute(name = "evalResult",
                        description = "The predicted value (`true/false`)",
                        type = {DataType.BOOL}),
                @ReturnAttribute(name = "matchedCondition",
                        description = "The probability of the prediction",
                        type = {DataType.STRING})
        },
        examples = @Example(description = "This returns a boolean value by evaluation the given expression. " +
                "In this case, it will return true as the output",
                syntax = "bny:eval(\"10 > 5\")")
)
public class EvaluateFunctionExtension extends StreamProcessor {

    private static final Logger log = Logger.getLogger(EvaluateFunctionExtension.class);

    @Override
    protected List<Attribute> init(AbstractDefinition abstractDefinition, ExpressionExecutor[] expressionExecutors,
                                   ConfigReader configReader, SiddhiAppContext siddhiAppContext) {

        if (attributeExpressionExecutors.length >= 1) {
            if (attributeExpressionExecutors[0] == null) {
                throw new SiddhiAppValidationException("bny:eval 1st parameter, logical expression needs " +
                        "to be non empty");
            }
        } else {
            throw new SiddhiAppValidationException("bny:eval should only have one parameter but found "
                    + attributeExpressionExecutors.length + " input attributes");
        }

        List<Attribute> attributes = new ArrayList<>();
        attributes.add(new Attribute("evalResult", Attribute.Type.BOOL));
        attributes.add(new Attribute("matchedCondition", Attribute.Type.STRING));
        return attributes;
    }

    @Override
    protected void process(ComplexEventChunk<StreamEvent> streamEventChunk, Processor processor,
                           StreamEventCloner streamEventCloner, ComplexEventPopulater complexEventPopulater) {

        synchronized (this) {
            while (streamEventChunk.hasNext()) {
                String expression = "";
                String unPopulated = "";
                StreamEvent event = streamEventChunk.next();
                if (attributeExpressionExecutors[0].execute(event) != null) {
                    expression = (String) attributeExpressionExecutors[0].execute(event);
                }

                if (attributeExpressionExecutors[1].execute(event) != null) {
                    unPopulated = (String) attributeExpressionExecutors[1].execute(event);
                }

                boolean evalResult = execute(expression);
                String trueExpression = unPopulated;
                List<String> matched = new ArrayList<>();

                if (expression.contains("||")) {
                    String[] tokens = expression.split("||");
                    String[] unPopulatedTokens = unPopulated.split("||");
                    for (int i = 0; i < tokens.length; i++) {
                        if (execute(tokens[i])) {
                            matched.add(unPopulatedTokens[i]);
                        }
                    }
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < matched.size(); i++) {
                        sb.append(matched.get(i));
                        if (i != (matched.size() - 1)) {
                            sb.append(" AND ");
                        }
                    }
                    trueExpression = sb.toString();
                }

                trueExpression = trueExpression.replace("&&", "AND");
                trueExpression = trueExpression.replace("==", "IS EQUAL TO");
                trueExpression = trueExpression.replace("\"", "");

                Object[] out = {evalResult, trueExpression};
                // If output has values, then add those values to output stream
                complexEventPopulater.populateComplexEvent(event, out);
            }
        }
        nextProcessor.process(streamEventChunk);

    }

    private boolean execute(String expression) {

        if (log.isDebugEnabled()) {
            log.debug("Executing expression " + expression);
        }
        ScriptEngine engine = new ScriptEngineManager().getEngineByName("nashorn");
        Object bool = false;
        try {
            if (expression != null || !(expression.isEmpty())) {
                bool = engine.eval(expression);
                if (log.isDebugEnabled()) {
                    log.debug("Result for the expression('" + expression + "') : " + bool);
                }
            } else {
                log.error("Expression is null or empty");
            }
            return (boolean) bool;
        } catch (ScriptException e) {
            log.error("Error occurred evaluating expression, " + expression);
            return false;
        }
    }

    /**
     * Used to collect the serializable state of the processing element, that need to be
     * persisted for reconstructing the element to the same state on a different point of time
     *
     * @return stateful objects of the processing element as an map
     */
    @Override
    public Map<String, Object> currentState() {

        return null;
    }

    /**
     * Used to restore serialized state of the processing element, for reconstructing
     * the element to the same state as if was on a previous point of time.
     *
     * @param state the stateful objects of the processing element as a map.
     *              This is the same map that is created upon calling currentState() method.
     */
    @Override
    public void restoreState(Map<String, Object> state) {

    }

    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }
}
