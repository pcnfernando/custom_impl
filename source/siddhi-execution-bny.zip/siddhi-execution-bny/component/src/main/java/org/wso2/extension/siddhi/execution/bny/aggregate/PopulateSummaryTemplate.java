package org.wso2.extension.siddhi.execution.bny.aggregate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.wso2.extension.siddhi.execution.bny.util.CreateMapFromJSON;
import org.wso2.extension.siddhi.execution.bny.util.PopulateFromMap;
import org.wso2.siddhi.annotation.Example;
import org.wso2.siddhi.annotation.Extension;
import org.wso2.siddhi.annotation.Parameter;
import org.wso2.siddhi.annotation.ReturnAttribute;
import org.wso2.siddhi.annotation.util.DataType;
import org.wso2.siddhi.core.config.SiddhiAppContext;
import org.wso2.siddhi.core.exception.SiddhiAppRuntimeException;
import org.wso2.siddhi.core.executor.ExpressionExecutor;
import org.wso2.siddhi.core.query.selector.attribute.aggregator.AttributeAggregator;
import org.wso2.siddhi.core.util.config.ConfigReader;
import org.wso2.siddhi.query.api.definition.Attribute;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * createMap(MQ_Raw_Event, GroupedKeys)
 * Returns a map with extracted keys and values.
 * Accept Type(s): (STRING,STRING)
 * Return Type(s): OBJECT
 */

@Extension(
        name = "populateSummary",
        namespace = "bny",
        description = "Returns a map with values extracted from the raw event. ",
        parameters = {
                @Parameter(name = "raw.input.string",
                        description = "The input string to be processed.",
                        type = {DataType.STRING}),
                @Parameter(name = "process.string",
                        description = "Process string",
                        type = {DataType.STRING})
        },
        returnAttributes = @ReturnAttribute(
                description = "This returns a map with values extracted from the raw event.",
                type = {DataType.OBJECT}),
        examples = @Example(description = "This returns a boolean value by evaluation the given expression. " +
                "In this case, it will return true as the output",
                syntax = "bny:eval(\"10 > 5\")")
)
public class PopulateSummaryTemplate extends AttributeAggregator {

    private static final Logger LOG = LoggerFactory.getLogger(PopulateSummaryTemplate.class);

    private static final String SUMMARY_HEADER_REGEX = "(BatchEmail_GroupHeader\\?=\\?)((.|\\n)+?)\\*=\\*";
    private static final String SUMMARY_FOOTER_REGEX = "(BatchEmail_GroupFooter\\?=\\?)((.|\\n)+?)\\*=\\*";

    private String summaryHeader;
    private String summaryFooter;

    private String concatenatedTemplate;

    Attribute.Type returnType = Attribute.Type.STRING;
    private Map<String, List<String>> map;
    private boolean canDistroy = true;
    //private List<String> list;

    @Override
    protected void init(ExpressionExecutor[] attributeExpressionExecutors, ConfigReader configReader,
                        SiddhiAppContext siddhiAppContext) {

        LOG.info("Inside Init######");
        map = new HashMap<>();

    }

    @Override
    public Attribute.Type getReturnType() {

        return returnType;
    }

    @Override
    public Object processAdd(Object o) {

        LOG.info("Inside processAdd######");
        return null;
    }

    @Override
    public Object processAdd(Object[] objects) {

        LOG.info("processAdd######" + objects[0]);
        for (int i = 0; i < objects.length; i++) {
            if (objects[i] == null) {
                LOG.info("Null" + objects[i]);
                throw new SiddhiAppRuntimeException(String.format("Invalid input given to str:createEvalStr() " +
                        "function. %s argument cannot be null", (i + 1)));
            }
        }

        String alertCategory = (String) objects[0];
        String summaryType = (String) objects[1];
        concatenatedTemplate = (String) objects[2];
        String batchTemplate = (String) objects[3];
        String actionString = (String) objects[4];

        //String realTimeAlert = (String) objects[4];

        //String batchTable = "";
        //String realTimeTable = "";
        //String subject = "";

        if (map.get(alertCategory) == null) {
            LOG.info("Map did't have alertCategory:" + alertCategory);
            List<String> list = new ArrayList<>();
            map.put(alertCategory, list);
        }

        LOG.info("Came out creating the map");

        if (summaryHeader == null) {
            LOG.info("Didn't have summaryHeader:");
            summaryHeader = runRegex(SUMMARY_HEADER_REGEX, concatenatedTemplate, 2);
        }
        if (summaryFooter == null) {
            LOG.info("Didn't have summaryFooter:");
            summaryFooter = runRegex(SUMMARY_FOOTER_REGEX, concatenatedTemplate, 2);
        }

        LOG.info("Created summaryHeader and summaryFooter");

        Map propertiesMap = (Map) CreateMapFromJSON.createMapFromJson(actionString);

        LOG.info("Created properties map");

        String populatedTemplate = PopulateFromMap.populateTemplateFromMap(propertiesMap, batchTemplate);

        LOG.info("Created populatedTemplate");
        map.get(alertCategory).add(populatedTemplate);

        return constructConcatString();
    }

    private boolean checkNull(Object[] obj) {

        boolean isNull = false;
        for (Object o : obj) {
            if (o == null) {
                isNull = true;
            }
        }
        return isNull;
    }

    private Object constructConcatString() {

        LOG.info("Inside constructConcatString######");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(summaryHeader);
        Iterator<Map.Entry<String, List<String>>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            LOG.info("Inside While######");
            Map.Entry<String, List<String>> pair = (Map.Entry<String, List<String>>) iterator.next();
            String groupHeaderRegex = "(BatchEmail_GroupHeader_";
            groupHeaderRegex = groupHeaderRegex.concat(pair.getKey()).concat("\\?=\\?)((.|\\n)+?)\\*=\\*");
            String typeHeader = runRegex(groupHeaderRegex, concatenatedTemplate, 2);
            stringBuilder.append(typeHeader);
            List<String> value = (ArrayList<String>) pair.getValue();
            for (String message : value) {
                LOG.info("Inside For######");
                stringBuilder.append(message);
            }
            String groupFooterRegex = "(BatchEmail_GroupFooter_";
            groupFooterRegex = groupFooterRegex.concat(pair.getKey()).concat("\\?=\\?)((.|\\n)+?)\\*=\\*");
            String typeFOOTER = runRegex(groupFooterRegex, concatenatedTemplate, 2);
            stringBuilder.append(typeFOOTER);
        }
        stringBuilder.append(summaryFooter);
        return stringBuilder.toString();
    }

    private String runRegex(String regex, String content, int groupNo) {

        LOG.info("Running regex: " + regex);
        String result = "";
        Pattern regexPattern = Pattern.compile(regex);
        Matcher regexMatcher = regexPattern.matcher(content);
        if (regexMatcher.find()) {
            result = regexMatcher.group(groupNo);
            LOG.info(String.format("Result for regex: %s is :", regex, result));
            if (LOG.isDebugEnabled()) {
                LOG.debug(String.format("Result for regex: %s is :", regex, result));
            }
        } else {
            LOG.error("No matches found for " + regex);
        }
        return result;
    }

    @Override
    public Object processRemove(Object o) {

        return null;
    }

    @Override
    public Object processRemove(Object[] objects) {

        removeString(objects);
        return constructConcatString();
    }

    private void removeString(Object[] data) {

        map.remove(data[0]);
        if (map.size() == 0) {
            canDistroy = true;
        }
    }

    @Override
    public boolean canDestroy() {

        return canDistroy;
    }

    @Override
    public Object reset() {

        map.clear();
        canDistroy = true;
        return "";
    }

    @Override
    public Map<String, Object> currentState() {

        return null;    //No need to maintain a state.
    }

    @Override
    public void restoreState(Map<String, Object> map) {

    }
}


