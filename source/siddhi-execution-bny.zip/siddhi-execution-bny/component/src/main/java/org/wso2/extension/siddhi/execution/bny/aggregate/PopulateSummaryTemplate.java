package org.wso2.extension.siddhi.execution.bny.aggregate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.wso2.extension.siddhi.execution.bny.util.CreateMapFromJSON;
import org.wso2.extension.siddhi.execution.bny.util.PopulateFromMap;
import org.wso2.siddhi.annotation.Example;
import org.wso2.siddhi.annotation.Extension;
import org.wso2.siddhi.annotation.Parameter;
import org.wso2.siddhi.annotation.ReturnAttribute;
import org.wso2.siddhi.annotation.util.DataType;
import org.wso2.siddhi.core.config.SiddhiAppContext;
import org.wso2.siddhi.core.executor.ExpressionExecutor;
import org.wso2.siddhi.core.query.selector.attribute.aggregator.AttributeAggregator;
import org.wso2.siddhi.core.util.config.ConfigReader;
import org.wso2.siddhi.query.api.definition.Attribute;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * createMap(MQ_Raw_Event, GroupedKeys)
 * Returns a map with extracted keys and values.
 * Accept Type(s): (STRING,STRING)
 * Return Type(s): OBJECT
 */

@Extension(
        name = "populateSummary",
        namespace = "bny",
        description = "Returns a map with values extracted from the raw event. ",
        parameters = {
                @Parameter(name = "raw.input.string",
                        description = "The input string to be processed.",
                        type = {DataType.STRING}),
                @Parameter(name = "process.string",
                        description = "Process string",
                        type = {DataType.STRING})
        },
        returnAttributes = @ReturnAttribute(
                description = "This returns a map with values extracted from the raw event.",
                type = {DataType.OBJECT}),
        examples = @Example(description = "This returns a boolean value by evaluation the given expression. " +
                "In this case, it will return true as the output",
                syntax = "bny:eval(\"10 > 5\")")
)
public class PopulateSummaryTemplate extends AttributeAggregator {

    private static final Logger LOG = LoggerFactory.getLogger(PopulateSummaryTemplate.class);

    private static final String SUMMARY_HEADER_REGEX = "(BatchEmail_GroupHeader\\?=\\?)((.|\\n)+?)\\*=\\*";
    private static final String SUMMARY_FOOTER_REGEX = "(BatchEmail_GroupFooter\\?=\\?)((.|\\n)+?)\\*=\\*";

    private String summaryHeader;
    private String summaryFooter;

    Attribute.Type returnType = Attribute.Type.STRING;
    private Map<String, List<String>> map;
    private boolean canDistroy = true;
    //private List<String> list;

    @Override
    protected void init(ExpressionExecutor[] attributeExpressionExecutors, ConfigReader configReader,
                        SiddhiAppContext siddhiAppContext) {

        map = new HashMap<>();

    }

    @Override
    public Attribute.Type getReturnType() {

        return returnType;
    }

    @Override
    public Object processAdd(Object o) {

        return null;
    }

    @Override
    public Object processAdd(Object[] objects) {

        if (!checkNull(objects)) {
            String alertCategory = (String) objects[0];
            String summaryType = (String) objects[1];
            String concatenatedTemplate = (String) objects[2];
            String batchTemplate = (String) objects[3];
            String actionString = (String) objects[4];

            //String realTimeAlert = (String) objects[4];

            //String batchTable = "";
            //String realTimeTable = "";
            //String subject = "";

            if (map.get(alertCategory) == null) {
                List<String> list = new ArrayList<>();
                map.put(alertCategory, list);
            }

            if (summaryHeader == null) {
                summaryHeader = runRegex(SUMMARY_HEADER_REGEX, concatenatedTemplate, 2);
            }
            if (summaryFooter == null) {
                summaryFooter = runRegex(SUMMARY_FOOTER_REGEX, concatenatedTemplate, 2);
            }

        /*Pattern batchTemplateRegexpattern = Pattern.compile("(<br><B>)((<table)(.|\\n)*?(<\\/table>))");
        Matcher batchTemplateMatcher = batchTemplateRegexpattern.matcher(batchTemplate);
        if (batchTemplateMatcher.find()) {
            batchTable = batchTemplateMatcher.group(2);
            if (LOG.isDebugEnabled()) {
                LOG.debug("batchTable: " + batchTable);
            }
        } else {
            LOG.error("No matches found for batchTable: (<br><B>)((<table)(.|\\n)*?(<\\/table>))");
        }*/

       /* Pattern realtimeAlertRegexpattern = Pattern.compile("<body>(.|\\n)?(<br><B>)((<table)(.|\\n)*?(<\\/table>))");
        Matcher realtimeAlertMatcher = realtimeAlertRegexpattern.matcher(realTimeAlert);
        if (realtimeAlertMatcher.find()) {
            realTimeTable = realtimeAlertMatcher.group(3);
            if (LOG.isDebugEnabled()) {
                LOG.debug("realTimeTable: " + realTimeTable);
            }
        } else {
            LOG.error("No matches found for realTimeTable: <body>(.|\\n)?(<br><B>)((<table)(.|\\n)*?(<\\/table>))");
        }*/

            //batchTemplate = batchTemplate.replace(batchTable, realTimeTable);
            Map propertiesMap = (Map) CreateMapFromJSON.createMapFromJson(actionString);
            String populatedTemplate = PopulateFromMap.populateTemplateFromMap(propertiesMap, batchTemplate);
            map.get(alertCategory).add(populatedTemplate);

        /*String groupHeader = "";
        String groupFooter = "";
        String gHeader = "";
        String gFooter = "";
        String subject = "";

        String groupHeaderRegex = "(BatchEmail_GroupHeader_";
        groupHeaderRegex = groupHeaderRegex.concat(alertCategory).concat("\\?=\\?)((.|\\n)+?)\\*=\\*");

        String groupFooterRegex = "(BatchEmail_GroupFooter_";
        groupFooterRegex = groupFooterRegex.concat(alertCategory).concat("\\?=\\?)((.|\\n)+?)\\*=\\*");

        String gHeaderRegex = "(BatchEmail_GroupHeader\\?=\\?)((.|\\n)+?)\\*=\\*";
        String gFooterRegex = "(BatchEmail_GroupFooter\\?=\\?)((.|\\n)+?)\\*=\\*";
        String subjectRegex = "(BatchEmail_GroupSubj\\?=\\?)((.|\\n)+?)\\*=\\*";

        Pattern groupHeaderRegexpattern = Pattern.compile(groupHeaderRegex);
        Matcher groupHeaderMatcher = groupHeaderRegexpattern.matcher(concatenatedTemplate);
        if (groupHeaderMatcher.find()) {
            groupHeader = groupHeaderMatcher.group(2);
            if (LOG.isDebugEnabled()) {
                LOG.debug("GroupHeader: " + groupHeader);
            }
        } else {
            LOG.error("No matches found for " + groupHeaderRegex);
        }

        Pattern groupFooterRegexRegexpattern = Pattern.compile(groupFooterRegex);
        Matcher groupFooterRegexMatcher = groupFooterRegexRegexpattern.matcher(concatenatedTemplate);
        if (groupFooterRegexMatcher.find()) {
            groupFooter = groupFooterRegexMatcher.group(2);
            if (LOG.isDebugEnabled()) {
                LOG.debug("GroupFooter: " + groupFooter);
            }
        } else {
            LOG.error("No matches found for " + groupFooterRegex);
        }

        Pattern gHeaderRegexPattern = Pattern.compile(gHeaderRegex);
        Matcher gHeaderRegexMatcher = gHeaderRegexPattern.matcher(concatenatedTemplate);
        if (gHeaderRegexMatcher.find()) {
            gHeader = gHeaderRegexMatcher.group(2);
            if (LOG.isDebugEnabled()) {
                LOG.debug("gHeader: " + gHeader);
            }
        } else {
            LOG.error("No matches found for " + gHeaderRegex);
        }

        Pattern gFooterRegexPattern = Pattern.compile(gFooterRegex);
        Matcher gFooterRegexMatcher = gFooterRegexPattern.matcher(concatenatedTemplate);
        if (gFooterRegexMatcher.find()) {
            gFooter = gFooterRegexMatcher.group(2);
            if (LOG.isDebugEnabled()) {
                LOG.debug("gFooter: " + gFooter);
            }
        } else {
            LOG.error("No matches found for " + gFooterRegex);
        }

        Pattern subjectRegexPattern = Pattern.compile(subjectRegex);
        Matcher subjectRegexMatcher = subjectRegexPattern.matcher(concatenatedTemplate);
        if (subjectRegexMatcher.find()) {
            subject = subjectRegexMatcher.group(2);
            if (LOG.isDebugEnabled()) {
                LOG.debug("subject: " + subject);
            }
        } else {
            LOG.error("No matches found for " + subjectRegex);
        }*/



        /*return String.format("############%s\n##############%s\n############%s\n#############%s\n##############%s\n"
                , groupHeader, groupFooter, gHeader, gFooter, subject);*/
            return constructConcatString(concatenatedTemplate);
        } else {
            return "No Alerts for the period";
        }

    }

    private boolean checkNull(Object[] obj) {

        boolean isNull = false;
        for (Object o : obj) {
            if (o == null) {
                isNull = true;
            }
        }
        return isNull;
    }

    private Object constructConcatString(String concatenatedTemplate) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(summaryHeader);
        Iterator<Map.Entry<String, List<String>>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, List<String>> pair = (Map.Entry<String, List<String>>) iterator.next();
            String groupHeaderRegex = "(BatchEmail_GroupHeader_";
            groupHeaderRegex = groupHeaderRegex.concat(pair.getKey()).concat("\\?=\\?)((.|\\n)+?)\\*=\\*");
            String typeHeader = runRegex(groupHeaderRegex, concatenatedTemplate, 2);
            stringBuilder.append(typeHeader);
            List<String> value = (ArrayList<String>) pair.getValue();
            for (String message : value) {
                stringBuilder.append(message);
            }
            String groupFooterRegex = "(BatchEmail_GroupFooter_";
            groupFooterRegex = groupFooterRegex.concat(pair.getKey()).concat("\\?=\\?)((.|\\n)+?)\\*=\\*");
            String typeFOOTER = runRegex(groupFooterRegex, concatenatedTemplate, 2);
            stringBuilder.append(typeFOOTER);
        }
        stringBuilder.append(summaryFooter);
        return stringBuilder.toString();
    }

    private String runRegex(String regex, String content, int groupNo) {

        String result = "";
        Pattern regexPattern = Pattern.compile(regex);
        Matcher regexMatcher = regexPattern.matcher(content);
        if (regexMatcher.find()) {
            result = regexMatcher.group(groupNo);
            if (LOG.isDebugEnabled()) {
                LOG.debug(String.format("Result for regex: %s is :", regex, result));
            }
        } else {
            LOG.error("No matches found for " + regex);
        }
        return result;
    }

    @Override
    public Object processRemove(Object o) {

        return null;
    }

    @Override
    public Object processRemove(Object[] objects) {

        return null;
    }

    @Override
    public boolean canDestroy() {

        return canDistroy;
    }

    @Override
    public Object reset() {

        map.clear();
        canDistroy = true;
        return "";
    }

    @Override
    public Map<String, Object> currentState() {

        return null;    //No need to maintain a state.
    }

    @Override
    public void restoreState(Map<String, Object> map) {

    }
}


