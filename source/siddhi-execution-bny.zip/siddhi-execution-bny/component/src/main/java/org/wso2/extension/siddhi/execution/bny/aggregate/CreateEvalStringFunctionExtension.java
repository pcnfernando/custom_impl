/*
 * Copyright (c) 2018, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.wso2.extension.siddhi.execution.bny.aggregate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.wso2.extension.siddhi.execution.bny.bean.Expression;
import org.wso2.siddhi.annotation.Example;
import org.wso2.siddhi.annotation.Extension;
import org.wso2.siddhi.annotation.Parameter;
import org.wso2.siddhi.annotation.ReturnAttribute;
import org.wso2.siddhi.annotation.util.DataType;
import org.wso2.siddhi.core.config.SiddhiAppContext;
import org.wso2.siddhi.core.exception.SiddhiAppRuntimeException;
import org.wso2.siddhi.core.executor.ExpressionExecutor;
import org.wso2.siddhi.core.query.selector.attribute.aggregator.AttributeAggregator;
import org.wso2.siddhi.core.util.config.ConfigReader;
import org.wso2.siddhi.query.api.definition.Attribute;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * createEvalStr(PropertiesMap, VARL_NM, VARL_OPER_CD ,VARL_VAL_TX ,OPER_CD , VARL_TY_CD, RULE_SEQ_NR, 'true/false')
 * Returns a logical expression string. 'true/false' flag is a flag to whether populate the
 * Variables in the expression.
 * Accept Type(s): OBJECT. Properties map created from the Raw message.
 * Accept Type(s): STRING. VARL_NM.
 * Accept Type(s): STRING. VARL_OPER_CD.
 * Accept Type(s): STRING. VARL_VAL_TX
 * Accept Type(s): STRING. OPER_CD
 * Accept Type(s): STRING. VARL_TY_CD
 * Accept Type(s): STRING. RULE_SEQ_NR
 * Accept Type(s): BOOLEAN. Flag to specify whether to populate the Variables used in the expressions or not.
 * Return Type(s): STRING
 */

@Extension(
        name = "createEvalStr",
        namespace = "bny",
        description = "Creates a logical expression string from each of the provided expressions per RuleID.",
        parameters = {
                @Parameter(name = "key.list",
                        description = "The string that need to be aggregated.",
                        type = {DataType.STRING})
        },
        returnAttributes = @ReturnAttribute(
                description = "Returns a string that is the result of the concatenated keys " +
                        "separated by the given separator",
                type = {DataType.STRING}),
        examples = {
                @Example(description = "This returns a string that is the result of the " +
                        "concatenated keys separated by the given separator. \n" +
                        "When we send events having values for the `key` `'A'`, `'B'`, `'S'`, `'C'`, `'A'` it will" +
                        " return `\"A-B-C-S\"` as the output",
                        syntax = "from InputStream#window.time(5 min)\n" +
                                "select groupConcat(\"key\",\"-\",true,\"ASC\") as groupedKeys\n" +
                                "insert into OutputStream;")
        }

)
public class CreateEvalStringFunctionExtension extends AttributeAggregator {

    private static final Logger LOG = LoggerFactory.getLogger(CreateEvalStringFunctionExtension.class);
    private Attribute.Type returnType = Attribute.Type.STRING;
    private boolean canDistroy = true;
    private List<Expression> expressionList = new ArrayList<>();
    private Map<String, String> propertiesMap = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
    private static final String SKIP_CHARACTOR_FIELDNAME = "SKIPOVER";
    private boolean populateString = false;

    @Override
    protected void init(ExpressionExecutor[] attributeExpressionExecutors, ConfigReader configReader,
                        SiddhiAppContext siddhiAppContext) {

    }

    @Override
    public Attribute.Type getReturnType() {

        return returnType;
    }

    @Override
    public Object processAdd(Object o) {

        return null;  //Since the extractValues function takes in exactly 2 parameters, this method does not get called.
        // Hence, not implemented.
    }

    @Override
    public Object processAdd(Object[] objects) {

        for (int i = 0; i < objects.length; i++) {
            if (objects[i] == null) {
                throw new SiddhiAppRuntimeException(String.format("Invalid input given to str:createEvalStr() " +
                        "function. %s argument cannot be null", (i + 1)));
            }
        }
        Map<String, String> property = (LinkedHashMap<String, String>) objects[0];
        property.forEach(propertiesMap::putIfAbsent);
        Expression expression = new Expression((String) objects[1], (String) objects[2],
                (String) objects[3], (String) objects[4], (String) objects[5],
                (String) objects[6], Integer.parseInt((String) objects[7]));
        expressionList.add(expression);
        return constructConcatString();
    }

    private String evaluate(Expression expression, Boolean populateString) {

        Object mapValue;
        if (populateString) {
            mapValue = propertiesMap.get(expression.getVarlNm());
        } else {
            mapValue = expression.getVarlNm();
        }
        if (mapValue == null ||
                (!(expression.getVarlNm().equalsIgnoreCase(SKIP_CHARACTOR_FIELDNAME))
                        && ((String) mapValue).trim().isEmpty())) {
            LOG.error(String.format("Key %s returns a null while parsing expression, ",
                    expression.getVarlNm(), expression.toString()));
            //LOG.error("Key: " + expression.getVarlNm() + " returns a null");
            //LOG.error(expression.toString());
        }
        String refValue = expression.getVarlValTx();
        String valueType = expression.getVarlTyCd();
        if ("EQ".equalsIgnoreCase(expression.getVarlOperCd())) {
            return generateExpress(mapValue, refValue, valueType, "==");
        } else if ("GE".equalsIgnoreCase(expression.getVarlOperCd())) {
            return generateExpress(mapValue, refValue, valueType, ">");
        } else if ("LE".equalsIgnoreCase(expression.getVarlOperCd())) {
            return generateExpress(mapValue, refValue, valueType, "<");
        } else if ("NOT".equalsIgnoreCase(expression.getVarlOperCd())) {
            return generateExpress(mapValue, refValue, valueType, "!");
        } else {
            throw new RuntimeException();
        }

    }

    private String generateExpress(Object mapValue, Object refrenceValue, String valueType, String ops) {

        StringBuilder build = new StringBuilder("(");
        if ("NUMBER".equalsIgnoreCase(valueType)) {
            build.append(mapValue).append(" ").append(ops).append(" ").append(refrenceValue);
        } else if ("STRING".equalsIgnoreCase(valueType)) {
            String upperCaseMapValue = ((String) mapValue).toUpperCase();
            build.append("\"").append(upperCaseMapValue).append("\" ").append(ops).append(" ").append("\"")
                    .append(((String) refrenceValue).toUpperCase()).append("\"");
        } else {
            throw new RuntimeException();
        }
        return build.append(")").toString();
    }

    @Override
    public Object processRemove(Object o) {

        return null;
    }

    @Override
    public Object processRemove(Object[] objects) {

        return null;
    }

    private Object constructConcatString() {

        StringBuilder populateStringBuilder = new StringBuilder();
        StringBuilder unpopulateStringBuilder = new StringBuilder();
        Map<String, String> output = new HashMap<>();
        Collections.sort(expressionList);
        for (Expression expression : expressionList) {
            populateStringBuilder.append(evaluate(expression, true));
            unpopulateStringBuilder.append(evaluate(expression, false));
            if ("AND".equalsIgnoreCase(expression.getOperCd())) {
                populateStringBuilder.append(" && ");
                unpopulateStringBuilder.append(" && ");
            } else if ("OR".equalsIgnoreCase(expression.getOperCd())) {
                populateStringBuilder.append(" || ");
                unpopulateStringBuilder.append(" || ");
            } else if ("END".equalsIgnoreCase(expression.getOperCd())) {
                String populated = populateStringBuilder.toString();
                String unpopulated = unpopulateStringBuilder.toString();
                output.put("populated", populated);
                output.put("unpopulated", unpopulated);
                return output;
            } else {
                throw new RuntimeException("Unidentified Operator, " + expression.getOperCd());
            }
        }
        String populated = populateStringBuilder.toString();
        String unpopulated = unpopulateStringBuilder.toString();
        output.put("populated", populated);
        output.put("unpopulated", unpopulated);
        return output;
    }

    @Override
    public boolean canDestroy() {

        return canDistroy;
    }

    @Override
    public Object reset() {

        canDistroy = true;
        return "";
    }

    @Override
    public Map<String, Object> currentState() {

        return null;
    }

    @Override
    public void restoreState(Map<String, Object> state) {

    }
}
