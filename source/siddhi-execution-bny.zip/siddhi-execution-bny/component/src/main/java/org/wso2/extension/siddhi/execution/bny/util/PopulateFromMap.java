package org.wso2.extension.siddhi.execution.bny.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public class PopulateFromMap {

    private static final Logger LOG = LoggerFactory.getLogger(PopulateFromMap.class);
    private static final String ALL_PLACEHOLDERS_REGEX = "\\$\\*.*?\\^";
    private static final String PLACEHODER_START_CHARACTORS = "\\$\\*";
    private static final String PLACEHODER_END_CHARACTORS = "\\^";
    private static final String ESCAPE_CHARACOR = "$";

    public static String populateTemplateFromMap(Map propertiesMap, String template) {

        /*HashMap<String, String> map = (HashMap<String, String>) propertiesMap;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String regex = "\\$\\*".concat(entry.getKey()).concat("\\^");
            String val = entry.getValue();
            if (val.contains("$")) {
                val = "\\".concat(val);
            }
            template = template.replaceAll(regex, val);
        }
        template = template.replaceAll("\\$\\*.*?\\^","");*/
        HashMap<String, String> map = (HashMap<String, String>) propertiesMap;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String regex = PLACEHODER_START_CHARACTORS.concat(entry.getKey()).concat(PLACEHODER_END_CHARACTORS);
            String val = entry.getValue();
            if (val.contains(ESCAPE_CHARACOR)) {
                val = "\\".concat(val);
            }
            template = template.replaceAll(regex, val);
        }
        template = template.replaceAll(ALL_PLACEHOLDERS_REGEX, "");
        return template;
    }
}
