package org.wso2.extension.siddhi.execution.bny.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public class PopulateFromMap {

    private static final Logger LOG = LoggerFactory.getLogger(PopulateFromMap.class);

    public static String populateTemplateFromMap(Map propertiesMap, String template) {

        HashMap<String, String> map = (HashMap<String, String>) propertiesMap;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String regex = "\\$\\*".concat(entry.getKey()).concat("\\^");
            LOG.info("Key: " + entry.getKey());
            LOG.info("Value: " + entry.getValue());
            String val = entry.getValue();
            if (val.contains("$")) {
                val = "\\".concat(val);
            }
            LOG.info("Replacing regex pattern : " + regex);
            template = template.replaceAll(regex, val);
        }
        return template;
    }
}
