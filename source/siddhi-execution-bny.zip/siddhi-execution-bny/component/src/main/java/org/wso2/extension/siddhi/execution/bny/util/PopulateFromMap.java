package org.wso2.extension.siddhi.execution.bny.util;

import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public class PopulateFromMap {
    public static String populateTemplateFromMap(Map propertiesMap, String template) {
        HashMap<String, String> map = (HashMap<String, String>) propertiesMap;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String regex = "\\$\\*".concat(entry.getKey()).concat("\\^");
            String val = entry.getValue();
            if (val.contains("$")) {
                val = "\\".concat(val);
            }
            template = template.replaceAll(regex, val);
        }
        return template;
    }
}
